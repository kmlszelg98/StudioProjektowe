package Simulation;

import Map.Terrain;
import Map.City;
import agents.HumanAgent;
import agents.Week.HumanWeek;
import generators.ActivityGenerator;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

import java.awt.*;

/**
 * Created by anka on 10.01.17.
 */
public class Generator {
    private Terrain map;
    private City city;
    private HumanAgent agent;

    public Generator(ContainerController containerController){
        map = new Terrain("map3.jpg");
        agent = new HumanAgent();
        agent.setup();
        try {
            AgentController ag = containerController.acceptNewAgent("Human_1",agent);
            ag.start();
        } catch (StaleProxyException e) {
            e.printStackTrace();
        }
        HumanWeek h = agent.getWeek();
        generate();
        //village = new Village(map, villageSize);

    }

    public void generate(){
        HumanWeek h = agent.getWeek();
        ActivityGenerator ac = new ActivityGenerator();
        int hx = agent.getHome().x;
        int hy = agent.getHome().y;
        do{
           ac.createActivity(h);
        }while(h.getLast().getTarget().x!=hx && h.getLast().getTarget().y!=hy);
        System.out.println(h);
    }
    // Drawing
    public void draw(Graphics g){
        map.draw(g);
        agent.draw(g);
        //village.draw(g);

    }

    public void moveAgent(int time){
        agent.move(time);
        //System.out.println(agent.getLocation());
    }
    // Getters
    public Terrain getMap() {
        return map;
    }
}
