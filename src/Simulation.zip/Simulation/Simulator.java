package Simulation;

import jade.wrapper.ContainerController;

import javax.swing.*;
import java.awt.*;

public class Simulator extends JPanel {

    private Generator generator;
    private boolean state;
    private int queue;
    private int time = 0;

    public Simulator(ContainerController containerController){
        this.state = false;
        this.queue = 0;
        this.generator = new Generator(containerController);
    }

    public void simulation(){
        generator.moveAgent(time);
        time = time+1;
        //System.out.println("Godzina :"+(int)(time/3600)+" minuta :"+(time%3600)/60);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        generator.draw(g);
        repaint();
    }

    // Getters and setters
    public void setState(boolean state) {
        this.state = state;
    }
    public boolean getState() {
        return state;
    }
}