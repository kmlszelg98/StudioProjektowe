package Simulation;

import jade.wrapper.ContainerController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.util.TimerTask;

/**
 * Created by anka on 15.01.17.
 */
public class GUI extends JFrame {
    private Simulator simulator;
    private java.util.Timer timer;
    private TimerTask task;
    private int height;
    private int width;

    public GUI (ContainerController containerController){
        super("City");
        super.frameInit();
        //System.out.println("Start GUI");
        this.getContentPane().setLayout(new CardLayout(0,0));
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Setting bounds
        this.setBounds(0, 0, 1600, 900);

        //Simulator
        simulator = new Simulator(containerController);
        getContentPane().add(simulator, "Simulator");

        //JLabel i_from = new JLabel("From");
        //getContentPane().add(i_from);

        // Setting visibility
        task = new TimerTask() {
            public void run() {
                simulator.simulation();
            }
        };

        timer = new java.util.Timer();
        timer.schedule(task,0,1000/60);
        simulator.setVisible(true);
        this.setVisible(true);
    }


    // Exit
    public void processWindowEvent(WindowEvent e) {
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
            this.dispose();
            System.out.print("\n\nQuitting the application!\n");
            System.exit(0);
        }
    }

    public int resize(double size){
        return (int) (height*size/1020);
    }
}



